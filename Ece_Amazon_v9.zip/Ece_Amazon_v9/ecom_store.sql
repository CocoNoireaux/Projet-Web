-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 03 mai 2019 à 14:21
-- Version du serveur :  5.7.24
-- Version de PHP :  7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ecom_store`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `admin_id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_pseudo` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_mdp` varchar(255) NOT NULL,
  `admin_image` text NOT NULL,
  `admin_pays` text NOT NULL,
  `admin_about` text NOT NULL,
  `admin_contact` varchar(255) NOT NULL,
  `admin_job` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_pseudo`, `admin_email`, `admin_mdp`, `admin_image`, `admin_pays`, `admin_about`, `admin_contact`, `admin_job`) VALUES
(2, 'Tatiana Saphira', 'tatiaCute@gmail.id', 'tatiana123', 'tatiana-saphira.jpg', 'Indonesia', 'Change the about description for Tatiana from chelsea Islan', '2222-2222-2222', 'MyMaid'),
(4, 'Nozomi Sasaki', 'papipupepo@gmail.jp', 'nozo123', 'Nozomi_Sasaki-.jpg', 'Japan', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui illum debitis dolorum ducimus aut maiores veritatis illo doloremque quibusdam placeat quod velit laudantium eligendi sunt et optio, harum in suscipit.', '312-009-323', 'MyWife'),
(5, 'Iko Uwais', 'iko@gmail.id', 'iko123', 'iko.png', 'Indonesia', 'This is for IKO', '081806833157', 'Fighter / Actor');

-- --------------------------------------------------------

--
-- Structure de la table `panier`
--

DROP TABLE IF EXISTS `panier`;
CREATE TABLE IF NOT EXISTS `panier` (
  `produit_id` int(10) NOT NULL,
  `ip_add` varchar(255) NOT NULL,
  `quantite_produit` int(10) NOT NULL,
  `taille` text NOT NULL,
  PRIMARY KEY (`produit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_titre` text NOT NULL,
  `cat_desc` text NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_titre`, `cat_desc`) VALUES
(1, ' Hommes', 'Articles orienté homme ici'),
(2, 'Femmes', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit rem eos illo tempora dicta possimus adipisci doloribus obcaecati odit officiis, sapiente eius excepturi harum voluptates nihil aut quo vero eveniet.'),
(3, 'Autres', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit rem eos illo tempora dicta possimus adipisci doloribus obcaecati odit officiis, sapiente eius excepturi harum voluptates nihil aut quo vero eveniet.');

-- --------------------------------------------------------

--
-- Structure de la table `acheteurs`
--

DROP TABLE IF EXISTS `acheteurs`;
CREATE TABLE IF NOT EXISTS `acheteurs` (
  `acheteur_id` int(10) NOT NULL AUTO_INCREMENT,
  `acheteur_nom` varchar(255) NOT NULL,
  `acheteur_email` varchar(255) NOT NULL,
  `acheteur_mdp` varchar(255) NOT NULL,
  `acheteur_pays` text NOT NULL,
  `acheteur_ville` text NOT NULL,
  `acheteur_contact` varchar(255) NOT NULL,
  `acheteur_adresse` text NOT NULL,
  `acheteur_image` text NOT NULL,
  `acheteur_ip` varchar(100) NOT NULL,
  PRIMARY KEY (`acheteur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `acheteurs`
--

INSERT INTO `acheteurs` (`acheteur_id`, `acheteur_nom`, `acheteur_email`, `acheteur_mdp`, `acheteur_pays`, `acheteur_ville`, `acheteur_contact`, `acheteur_adresse`, `acheteur_image`, `acheteur_ip`) VALUES
(5, 'Rianti', 'Riannti@gmail.com', 'rianti123', 'India', 'Calcuta', '8891822', 'Anywhere you want', 'member1.jpg', '::1'),
(6, 'James Bono', 'jamesbono@gmail.com', 'salut', 'England', 'London', '555-2255-222', 'Hyde Park', 'member2.jpg', '::1');

-- --------------------------------------------------------

--
-- Structure de la table `commandes`
--

DROP TABLE IF EXISTS `commandes`;
CREATE TABLE IF NOT EXISTS `commandes` (
  `commande_id` int(10) NOT NULL AUTO_INCREMENT,
  `acheteur_id` int(10) NOT NULL,
  `montant_du` int(100) NOT NULL,
  `n°facture` int(100) NOT NULL,
  `quantite_produit` int(10) NOT NULL,
  `taille` text NOT NULL,
  `commande_date` date NOT NULL,
  `commande_statut` text NOT NULL,
  PRIMARY KEY (`commande_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commandes`
--

INSERT INTO `commandes` (`commande_id`, `acheteur_id`, `montant_du`, `n°facture`, `quantite_produit`, `taille`, `commande_date`, `commande_statut`) VALUES
(11, 6, 300, 206863956, 1, 'Small', '2019-02-06', 'Complete'),
(12, 6, 10, 206863956, 1, 'Small', '2019-02-06', 'Complete'),
(13, 6, 121, 426714173, 1, 'Small', '2019-05-01', 'pending');

-- --------------------------------------------------------

--
-- Structure de la table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
CREATE TABLE IF NOT EXISTS `paiements` (
  `paiement_id` int(10) NOT NULL AUTO_INCREMENT,
  `n°facture` int(10) NOT NULL,
  `montant` int(10) NOT NULL,
  `paiement_mode` text NOT NULL,
  `n°ref` int(10) NOT NULL,
  `code` int(10) NOT NULL,
  `paiement_date` text NOT NULL,
  PRIMARY KEY (`paiement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `paiements`
--

INSERT INTO `paiements` (`paiement_id`, `n°facture`, `montant`, `paiement_mode`, `n°ref`, `code`, `paiement_date`) VALUES
(6, 206863956, 10, 'Western Union', 123123, 321321, '02-09-2019');

-- --------------------------------------------------------

--
-- Structure de la table `commandes_attentes`
--

DROP TABLE IF EXISTS `commandes_attentes`;
CREATE TABLE IF NOT EXISTS `commandes_attentes` (
  `commande_id` int(10) NOT NULL AUTO_INCREMENT,
  `acheteur_id` int(10) NOT NULL,
  `n°facture` int(10) NOT NULL,
  `produit_id` text NOT NULL,
  `quantite_produit` int(10) NOT NULL,
  `taille` text NOT NULL,
  `commande_statut` text NOT NULL,
  PRIMARY KEY (`commande_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commandes_attentes`
--

INSERT INTO `commandes_attentes` (`commande_id`, `acheteur_id`, `n°facture`, `produit_id`, `quantite_produit`, `taille`, `commande_statut`) VALUES
(9, 6, 206863956, '10', 1, 'Small', 'attente'),
(10, 6, 206863956, '15', 1, 'Small', 'attente'),
(11, 6, 426714173, '2', 1, 'Small', 'attente');

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

DROP TABLE IF EXISTS `produits`;
CREATE TABLE IF NOT EXISTS `produits` (
  `produit_id` int(10) NOT NULL AUTO_INCREMENT,
  `produit_cat_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `produit_titre` text NOT NULL,
  `produit_img1` text NOT NULL,
  `produit_img2` text NOT NULL,
  `produit_img3` text NOT NULL,
  `produit_video` text NOT NULL,
  `produit_prix` int(10) NOT NULL,
  `produit_motcle` text NOT NULL,
  `produit_desc` text NOT NULL,
  PRIMARY KEY (`produit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produits`
--

INSERT INTO `produits` (`produit_id`, `produit_cat_id`, `cat_id`, `date`, `produit_titre`, `produit_img1`, `produit_img2`, `produit_img3`, `produit_video`, `produit_prix`, `produit_motcle`, `produit_desc`) VALUES
(1, 3, 2, '2019-05-01 11:53:44', 'Dress', 'product_front.jpg', 'product-back.jpg', 'product_hang.jpg', '', 66, 'Dress', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, dolorem tempore deleniti delectus numquam quam magni quidem veniam sequi nostrum sed eaque. Reiciendis quisquam totam nobis corrupti ullam at debitis!</p>'),
(2, 3, 1, '2019-05-01 11:57:48', 'Boys Puffer Coat With Detachable Hood', 'boys-Puffer-Coat-With-Detachable-Hood-1.jpg', 'boys-Puffer-Coat-With-Detachable-Hood-2.jpg', 'boys-Puffer-Coat-With-Detachable-Hood-3.jpg', '', 121, 'Hood', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur cupiditate animi, voluptas neque quasi qui unde fuga porro vero magnam maiores optio amet quos temporibus? Amet saepe fugit nostrum a?</p>'),
(3, 3, 2, '2019-05-01 11:58:08', 'Girl Polos T-Shirt', 'g-polos-tshirt-1.jpg', 'g-polos-tshirt-2.jpg', '', '', 55, 'Shirt', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur cupiditate animi, voluptas neque quasi qui unde fuga porro vero magnam maiores optio amet quos temporibus? Amet saepe fugit nostrum a?</p>'),
(4, 3, 1, '2019-05-01 11:58:21', 'Man Geox Winter Jacket', 'Man-Geox-Winter-jacket-1.jpg', 'Man-Geox-Winter-jacket-2.jpg', 'Man-Geox-Winter-jacket-3.jpg', '', 100, 'Snake Skin', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur cupiditate animi, voluptas neque quasi qui unde fuga porro vero magnam maiores optio amet quos temporibus? Amet saepe fugit nostrum a?</p>'),
(5, 3, 2, '2019-05-01 11:58:33', 'Women Red Winter Jacket', 'Red-Winter-jacket-1.jpg', 'Red-Winter-jacket-2.jpg', 'Red-Winter-jacket-3.jpg', '', 103, 'Korean Jacket', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur cupiditate animi, voluptas neque quasi qui unde fuga porro vero magnam maiores optio amet quos temporibus? Amet saepe fugit nostrum a?</p>'),
(6, 4, 2, '2018-10-18 18:33:44', 'Woman Waxed Cotton Coat', 'waxed-cotton-coat-woman-1.jpg', 'waxed-cotton-coat-woman-2.jpg', 'waxed-cotton-coat-woman-3.jpg', '', 211, 'Cotton', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur cupiditate animi, voluptas neque quasi qui unde fuga porro vero magnam maiores optio amet quos temporibus? Amet saepe fugit nostrum a?</p>'),
(7, 3, 2, '2018-10-18 18:34:52', 'High Heels Pantofel Brukat', 'High Heels Women Pantofel Brukat-1.jpg', 'High Heels Women Pantofel Brukat-2.jpg', 'High Heels Women Pantofel Brukat-3.jpg', '', 45, 'High Heel', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur cupiditate animi, voluptas neque quasi qui unde fuga porro vero magnam maiores optio amet quos temporibus? Amet saepe fugit nostrum a?</p>'),
(8, 3, 1, '2018-10-18 18:35:45', 'Adidas Suarez Slop On', 'Man-Adidas-Suarez-Slop-On-1.jpg', 'Man-Adidas-Suarez-Slop-On-2.jpg', 'Man-Adidas-Suarez-Slop-On-3.jpg', '', 51, 'Adidas Suarez', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur cupiditate animi, voluptas neque quasi qui unde fuga porro vero magnam maiores optio amet quos temporibus? Amet saepe fugit nostrum a?</p>'),
(9, 3, 1, '2019-05-01 11:59:01', 'Mont Blanc Belt Man', 'Mont-Blanc-Belt-man-1.jpg', 'Mont-Blanc-Belt-man-2.jpg', 'Mont-Blanc-Belt-man-3.jpg', '', 166, 'Belt', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur cupiditate animi, voluptas neque quasi qui unde fuga porro vero magnam maiores optio amet quos temporibus? Amet saepe fugit nostrum a?</p>'),
(10, 3, 2, '2019-05-01 11:59:22', 'Diamond Heart Ring', 'women-diamond-heart-ring-1.jpg', 'women-diamond-heart-ring-2.jpg', 'women-diamond-heart-ring-3.jpg', '', 300, 'Ring', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur cupiditate animi, voluptas neque quasi qui unde fuga porro vero magnam maiores optio amet quos temporibus? Amet saepe fugit nostrum a?</p>'),
(11, 3, 1, '2019-05-01 11:59:35', 'Grey Man T-Shirt', 'grey-man-1.jpg', 'grey-man-2.jpg', 'grey-man-3.jpg', '', 50, 'Casual', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi rem nemo, autem at ad temporibus, maiores ducimus sed quam enim reprehenderit distinctio similique debitis, quis corrupti est. Sed, rem, voluptatibus!</p>'),
(12, 3, 1, '2019-05-01 11:59:45', 'Man Polo Casual T-Shirt', 'Man-Polo-1.jpg', 'Man-Polo-2.jpg', 'Man-Polo-3.jpg', '', 45, 'Casual', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi rem nemo, autem at ad temporibus, maiores ducimus sed quam enim reprehenderit distinctio similique debitis, quis corrupti est. Sed, rem, voluptatibus!</p>'),
(13, 3, 1, '2019-05-01 11:59:55', 'Boy Polos T-Shirt', 'polos-tshirt-1.jpg', 'polos-tshirt-2.jpg', '', '', 40, 'Casual', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi rem nemo, autem at ad temporibus, maiores ducimus sed quam enim reprehenderit distinctio similique debitis, quis corrupti est. Sed, rem, voluptatibus!</p>'),
(14, 3, 1, '2019-05-01 12:00:03', 'Levi`s Trucker Jacket', 'levis-Trucker-Jacket.jpg', 'levis-Trucker-Jacket-2.jpg', 'levis-Trucker-Jacket-3.jpg', '', 98, 'Trucker', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi rem nemo, autem at ad temporibus, maiores ducimus sed quam enim reprehenderit distinctio similique debitis, quis corrupti est. Sed, rem, voluptatibus!</p>'),
(15, 1, 3, '2019-05-01 13:16:58', 'Game of Thrones', 'game.jpg', '', 'game.mp4', '', 20, 'game', 'vol 1'),
(16, 2, 3, '2019-05-01 15:18:07', 'Charles Aznavour - Emmenez moi', 'emmenez_moi.jpg', '', '', 'https://www.youtube.com/embed/rmaBeo1M6vg', 10, 'aznavour', 'auteur: Charles Aznavour\r\n\r\netc'),
(17, 4, 3, '2019-05-01 20:17:49', 'DVD - Bruce lee- La fureur du dragon', 'bruce.png', '', '', 'https://www.youtube.com/embed/h-MxfVfRkZg', 10, 'fureur', 'realisé par :\r\n\r\nDate: ');

-- --------------------------------------------------------

--
-- Structure de la table `categories_produit`
--

DROP TABLE IF EXISTS `categories_produit`;
CREATE TABLE IF NOT EXISTS `categories_produit` (
  `produit_cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `produit_cat_titre` text NOT NULL,
  `produit_cat_desc` text NOT NULL,
  PRIMARY KEY (`produit_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categories_produit`
--

INSERT INTO `categories_produit` (`produit_cat_id`, `produit_cat_titre`, `produit_cat_desc`) VALUES
(1, 'Livres', 'Il y a tous les livres que vous souhaitez ici'),
(2, 'Musique', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit rem eos illo tempora dicta possimus adipisci doloribus obcaecati odit officiis, sapiente eius excepturi harum voluptates nihil aut quo vero eveniet.'),
(3, 'Vetements', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit rem eos illo tempora dicta possimus adipisci doloribus obcaecati odit officiis, sapiente eius excepturi harum voluptates nihil aut quo vero eveniet.'),
(4, 'Sports et loisirs', 'Films et pleins d\'autres produits');

-- --------------------------------------------------------

--
-- Structure de la table `slider`
--

DROP TABLE IF EXISTS `slider`;
CREATE TABLE IF NOT EXISTS `slider` (
  `slide_id` int(10) NOT NULL AUTO_INCREMENT,
  `slide_nom` varchar(255) NOT NULL,
  `slide_image` text NOT NULL,
  PRIMARY KEY (`slide_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `slider`
--

INSERT INTO `slider` (`slide_id`, `slide_nom`, `slide_image`) VALUES
(8, 'Slide Number 6', 'slide-6.jpg'),
(9, 'Slide Number 7', 'slide-7.jpg'),
(10, 'Editing Slide Number 8', 'slide-5.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `vendeurs`
--

DROP TABLE IF EXISTS `vendeurs`;
CREATE TABLE IF NOT EXISTS `vendeurs` (
  `vendeur_id` int(10) NOT NULL AUTO_INCREMENT,
  `vendeur_pseudo` varchar(255) NOT NULL,
  `vendeur_email` varchar(255) NOT NULL,
  `vendeur_mdp` varchar(255) NOT NULL,
  `vendeur_pays` text NOT NULL,
  `vendeur_ville` text NOT NULL,
  `vendeur_contact` varchar(255) NOT NULL,
  `vendeur_adresse` text NOT NULL,
  `vendeur_image` text NOT NULL,
  `vendeur_ip` varchar(100) NOT NULL,
  PRIMARY KEY (`vendeur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
