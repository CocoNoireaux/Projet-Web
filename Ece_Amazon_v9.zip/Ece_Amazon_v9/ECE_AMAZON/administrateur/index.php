<?php 

    session_start();
    include("includes/bdd.php");
    
    if(!isset($_SESSION['admin_email'])){
        
        echo "<script>window.open('connexion.php','_self')</script>";
        
    }else{
        
        $admin_session = $_SESSION['admin_email'];
        
        $get_admin = "select * from admins where admin_email='$admin_session'";
        
        $run_admin = mysqli_query($con,$get_admin);
        
        $row_admin = mysqli_fetch_array($run_admin);
        
        $admin_id = $row_admin['admin_id'];
        
        $admin_name = $row_admin['admin_pseudo'];
        
        $admin_email = $row_admin['admin_email'];
        
        $admin_image = $row_admin['admin_image'];
        
        $admin_country = $row_admin['admin_pays'];
        
        $admin_about = $row_admin['admin_about'];
        
        $admin_contact = $row_admin['admin_contact'];
        
        $admin_job = $row_admin['admin_job'];
        
        $get_products = "select * from produits";
        
        $run_products = mysqli_query($con,$get_products);
        
        $count_products = mysqli_num_rows($run_products);
        
        $get_customers = "select * from acheteurs";
        
        $run_customers = mysqli_query($con,$get_customers);
        
        $count_customers = mysqli_num_rows($run_customers);
        
        $get_p_categories = "select * from categories_produit";
        
        $run_p_categories = mysqli_query($con,$get_p_categories);
        
        $count_p_categories = mysqli_num_rows($run_p_categories);
        
        $get_pending_orders = "select * from commandes_attentes";
        
        $run_pending_orders = mysqli_query($con,$get_pending_orders);
        
        $count_pending_orders = mysqli_num_rows($run_pending_orders);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ECE Amazon: Espace Admin</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div id="wrapper"><!-- #wrapper begin -->
       
       <?php include("includes/sidebar.php"); ?>
       
        <div id="page-wrapper"><!-- #page-wrapper begin -->
            <div class="container-fluid"><!-- container-fluid begin -->
                
                <?php
                
                    if(isset($_GET['tab_bord'])){
                        
                        include("tab_bord.php");
                        
                }   if(isset($_GET['insert_produit'])){
                        
                        include("insert_produit.php");
                        
                }   if(isset($_GET['voir_produits'])){
                        
                        include("voir_produits.php");
                        
                }   if(isset($_GET['sup_produit'])){
                        
                        include("sup_produit.php");
                        
                }   if(isset($_GET['modif_produit'])){
                        
                        include("modif_produit.php");
                        
                }   if(isset($_GET['insert_produit_cat'])){
                        
                        include("insert_produit_cat.php");
                        
                }   if(isset($_GET['voir_produits_cats'])){
                        
                        include("voir_produits_cats.php");
                        
                }   if(isset($_GET['sup_produit_cat'])){
                        
                        include("sup_produit_cat.php");
                        
                }   if(isset($_GET['modif_produit_cat'])){
                        
                        include("modif_produit_cat.php");
                        
                }   if(isset($_GET['insert_cat'])){
                        
                        include("insert_cat.php");
                        
                }   if(isset($_GET['voir_cats'])){
                        
                        include("voir_cats.php");
                        
                }   if(isset($_GET['modif_cat'])){
                        
                        include("modif_cat.php");
                        
                }   if(isset($_GET['sup_cat'])){
                        
                        include("sup_cat.php");
                        
                }   if(isset($_GET['insert_slide'])){
                        
                        include("insert_slide.php");
                        
                }   if(isset($_GET['voir_slides'])){
                        
                        include("voir_slides.php");
                        
                }   if(isset($_GET['sup_slide'])){
                        
                        include("sup_slide.php");
                        
                }   if(isset($_GET['modif_slide'])){
                        
                        include("modif_slide.php");
                        
                }   if(isset($_GET['voir_acheteurs'])){
                        
                        include("voir_acheteurs.php");
                        
                }   if(isset($_GET['sup_acheteur'])){
                        
                        include("sup_acheteur.php");
                        
                }   if(isset($_GET['voir_commandes'])){
                        
                        include("voir_commandes.php");
                        
                }   if(isset($_GET['sup_commande'])){
                        
                        include("sup_commande.php");
                        
                }   if(isset($_GET['voir_paiements'])){
                        
                        include("voir_paiements.php");
                        
                }   if(isset($_GET['sup_paiement'])){
                        
                        include("sup_paiement.php");
                        
                }   if(isset($_GET['voir_utilisateurs'])){
                        
                        include("voir_utilisateurs.php");
                        
                }   if(isset($_GET['sup_utilisateur'])){
                        
                        include("sup_utilisateur.php");
                        
                }   if(isset($_GET['insert_utilisateur'])){
                        
                        include("insert_utilisateur.php");
                        
                }   if(isset($_GET['utilisateur_profil'])){
                        
                        include("utilisateur_profil.php");
                        
                }
        
                ?>
                
            </div><!-- container-fluid finish -->
        </div><!-- #page-wrapper finish -->
    </div><!-- wrapper finish -->

<script src="js/jquery-331.min.js"></script>     
<script src="js/bootstrap-337.min.js"></script>           
</body>
</html>


<?php } ?>