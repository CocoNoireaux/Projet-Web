<?php 
    
    if(!isset($_SESSION['admin_email'])){
        
        echo "<script>window.open('connexion.php','_self')</script>";
        
    }else{

?>

<?php 

    if(isset($_GET['sup_paiement'])){
        
        $delete_payment_id = $_GET['su-paiement'];
        
        $delete_payment = "delete from paiements where paiement_id='$delete_payment_id'";
        
        $run_delete = mysqli_query($con,$delete_payment);
        
        if($run_delete){
            
            echo "<script>alert('One of Your Payment Has Been Deleted')</script>";
            
            echo "<script>window.open('index.php?voir_paiements','_self')</script>";
            
        }
        
    }

?>




<?php } ?>