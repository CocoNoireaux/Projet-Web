<?php 

    session_start();
    session_destroy();

    echo "<script>window.open('connexion.php','_self')</script>";

?>