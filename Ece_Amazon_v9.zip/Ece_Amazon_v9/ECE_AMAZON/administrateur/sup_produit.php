<?php 
    
    if(!isset($_SESSION['admin_email'])){
        
        echo "<script>window.open('connexion.php','_self')</script>";
        
    }else{

?>

<?php 

    if(isset($_GET['sup_produit'])){
        
        $delete_id = $_GET['sup_produit'];
        
        $delete_pro = "delete from produits where produit_id='$delete_id'";
        
        $run_delete = mysqli_query($con,$delete_pro);
        
        if($run_delete){
            
            echo "<script>alert('One of your produit has been Deleted')</script>";
            
            echo "<script>window.open('index.php?voir_produits','_self')</script>";
            
        }
        
    }

?>

<?php } ?>