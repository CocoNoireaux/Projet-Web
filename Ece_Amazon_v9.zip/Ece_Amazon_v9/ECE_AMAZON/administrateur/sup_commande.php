<?php 
    
    if(!isset($_SESSION['admin_email'])){
        
        echo "<script>window.open('connexion.php','_self')</script>";
        
    }else{

?>

<?php 

    if(isset($_GET['sup_commande'])){
        
        $delete_id = $_GET['sup_commande'];
        
        $delete_order = "delete from commandes_attentes where commande_id='$delete_id'";
        
        $run_delete = mysqli_query($con,$delete_order);
        
        if($run_delete){
            
            echo "<script>alert('One of your costumer order has been Deleted')</script>";
            
            echo "<script>window.open('index.php?voir_commandes','_self')</script>";
            
        }
        
    }

?>

<?php } ?>