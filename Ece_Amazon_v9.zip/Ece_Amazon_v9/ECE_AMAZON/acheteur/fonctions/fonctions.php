<?php 

$bdd = mysqli_connect("localhost","root","","ecom_store");

/// begin getRealIpUser functions ///

function getRealIpUser(){
    
    switch(true){
            
            case(!empty($_SERVER['HTTP_X_REAL_IP'])) : return $_SERVER['HTTP_X_REAL_IP'];
            case(!empty($_SERVER['HTTP_CLIENT_IP'])) : return $_SERVER['HTTP_CLIENT_IP'];
            case(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) : return $_SERVER['HTTP_X_FORWARDED_FOR'];
            
            default : return $_SERVER['REMOTE_ADDR'];
            
    }
    
}

/// finish getRealIpUser functions ///

/// begin add_cart functions ///

function ajout_panier(){
    
    global $bdd;
    
    if(isset($_GET['ajout_panier'])){
        
        $ip_add = getRealIpUser();
        
        $produit_id = $_GET['ajout_panier'];
        
        $quantite_produit = $_POST['quantite_produit'];
        
        $produit_taille = $_POST['produit_taille'];
        
        $verification_produit = "select * from panier where ip_add='$ip_add' AND produit_id='$produit_id'";
        
        $run_verification = mysqli_query($bdd,$verification_produit);
        
        if(mysqli_num_rows($run_verification)>0){
            
            echo "<script>alert('Ce produit a déjà été ajouté dans le panier')</script>";
            echo "<script>window.open('details.php?pro_id=$produit_id','_self')</script>";
            
        }else{
            
            $query = "insert into panier (produit_id,ip_add,quantite_produit,taille) values ('$produit_id','$ip_add','$quantite_produit','$produit_taille')";
            
            $run_query = mysqli_query($bdd,$query);
            
            echo "<script>window.open('details.php?pro_id=$produit_id','_self')</script>";
            
        }
        
    }
    
}

/// finish add_cart functions ///

/// begin getPro functions ///

function getPro(){
    
    global $bdd;
    
    $get_produits = "select * from produits order by 1 DESC LIMIT 0,8";
    
    $run_produits = mysqli_query($bdd,$get_produits);
    
    while($row_produits=mysqli_fetch_array($run_produits)){
        
        $pro_id = $row_produits['produit_id'];
        
        $pro_titre = $row_produits['produit_titre'];
        
        $pro_prix = $row_produits['produit_prix'];
        
        $pro_img1 = $row_produits['produit_img1'];
        
        echo "
        
        <div class='col-md-4 col-sm-6 single'>
        
            <div class='produit'>
            
                <a href='details.php?pro_id=$pro_id'>
                
                    <img class='img-responsive' src='administrateur/produit_images/$pro_img1'>
                
                </a>
                
                <div class='text'>
                
                    <h3>
            
                        <a href='details.php?pro_id=$pro_id'>

                            $pro_titre

                        </a>
                    
                    </h3>
                    
                    <p class='prix'>
                    
                        $ $pro_prix
                    
                    </p>
                    
                    <p class='button'>
                    
                        <a class='btn btn-default' href='details.php?pro_id=$pro_id'>

                            Voir Details

                        </a>
                    
                        <a class='btn btn-primary' href='details.php?pro_id=$pro_id'>

                            <i class='fa fa-shopping-cart'></i> Ajouter au panier

                        </a>
                    
                    </p>
                
                </div>
            
            </div>
        
        </div>
        
        ";
        
    }
    
}

/// finish getPro functions ///

/// begin getPCats functions ///

function getPCats(){
    
    global $bdd;
    
    $get_produit_cats = "select * from categories_produit";
    
    $run_produit_cats = mysqli_query($bdd,$get_produit_cats);
    
    while($row_produit_cats=mysqli_fetch_array($run_produit_cats)){
        
        $produit_cat_id = $row_produit_cats['produit_cat_id'];
        
        $produit_cat_titre = $row_produit_cats['produit_cat_titre'];
        
        echo "
        
            <li>
            
                <a href='boutique.php?produit_cat=$produit_cat_id'> $produit_cat_titre </a>
            
            </li>
        
        ";
        
    }
    
}
    
/// finish getPCats functions ///

/// begin getCats functions ///

function getCats(){
    
    global $bdd;
    
    $get_cats = "select * from categories";
    
    $run_cats = mysqli_query($bdd,$get_cats);
    
    while($row_cats=mysqli_fetch_array($run_cats)){
        
        $cat_id = $row_cats['cat_id'];
        
        $cat_titre = $row_cats['cat_titre'];
        
        echo "
        
            <li>
            
                <a href='boutique.php?cat=$cat_id'> $cat_titre </a>
            
            </li>
        
        ";
        
    }
    
}
    
/// finish getCats functions ///

/// begin getpcatpro functions ///

function getpcatpro(){
    
    global $bdd;
    
    if(isset($_GET['produit_cat'])){
        
        $produit_cat_id = $_GET['produit_cat'];
        
        $get_produit_cat ="select * from categories_produit where produit_cat_id='$produit_cat_id'";
        
        $run_produit_cat = mysqli_query($bdd,$get_produit_cat);
        
        $row_produit_cat = mysqli_fetch_array($run_produit_cat);
        
        $produit_cat_titre = $row_produit_cat['produit_cat_titre'];
        
        $produit_cat_desc = $row_produit_cat['produit_cat_desc'];
        
        $get_produits ="select * from produits where produit_cat_id='$produit_cat_id'";
        
        $run_produits = mysqli_query($bdd,$get_produits);
        
        $count = mysqli_num_rows($run_produits);
        
        if($count==0){
            
            echo "
            
                <div class='box'>
                
                    <h1> Aucun produit trouvé dans cette catégorie </h1>
                
                </div>
            
            ";
            
        }else{
            
            echo "
            
                <div class='box'>
                
                    <h1> $produit_cat_titre </h1>
                    
                    <p> $produit_cat_desc </p>
                
                </div>
            
            ";
            
        }
        
        while($row_produits=mysqli_fetch_array($run_produits)){
            
            $pro_id = $row_produits['produit_id'];
        
            $pro_titre = $row_produits['produit_titre'];

            $pro_prix = $row_produits['produit_prix'];

            $pro_img1 = $row_produits['produit_img1'];
            
            echo "
            
                <div class='col-md-4 col-sm-6 center-responsive'>
        
            <div class='produit'>
            
                <a href='details.php?pro_id=$pro_id'>
                
                    <img class='img-responsive' src='administrateur/produit_images/$pro_img1'>
                
                </a>
                
                <div class='text'>
                
                    <h3>
            
                        <a href='details.php?pro_id=$pro_id'>

                            $pro_titre

                        </a>
                    
                    </h3>
                    
                    <p class='prix'>
                    
                        $ $pro_prix
                    
                    </p>
                    
                    <p class='button'>
                    
                        <a class='btn btn-default' href='details.php?pro_id=$pro_id'>

                            Voir Details

                        </a>
                    
                        <a class='btn btn-primary' href='details.php?pro_id=$pro_id'>

                            <i class='fa fa-shopping-cart'></i> Ajouter au panier

                        </a>
                    
                    </p>
                
                </div>
            
            </div>
        
        </div>
            
            ";
            
        }
        
    }
    
}

/// finish getpcatpro functions ///

/// begin getcatpro functions ///

function getcatpro(){
    
    global $bdd;
    
    if(isset($_GET['cat'])){
        
        $cat_id = $_GET['cat'];
        
        $get_cat = "select * from categories where cat_id='$cat_id'";
        
        $run_cat = mysqli_query($bdd,$get_cat);
        
        $row_cat = mysqli_fetch_array($run_cat);
        
        $cat_titre = $row_cat['cat_titre'];
        
        $cat_desc = $row_cat['cat_desc'];
        
        $get_cat = "select * from produits where cat_id='$cat_id' LIMIT 0,6";
        
        $run_produits = mysqli_query($bdd,$get_cat);
        
        $count = mysqli_num_rows($run_produits);
        
        if($count==0){
            
            
            echo "
            
                <div class='box'>
                
                    <h1> Aucun produit trouvé dans cette catégorie </h1>
                
                </div>
            
            ";
            
        }else{
            
            echo "
            
                <div class='box'>
                
                    <h1> $cat_titre </h1>
                    
                    <p> $cat_desc </p>
                
                </div>
            
            ";
            
        }
        
        while($row_produits=mysqli_fetch_array($run_produits)){
            
            $pro_id = $row_produits['produit_id'];
            
            $pro_titre = $row_produits['produit_titre'];
            
            $pro_prix = $row_produits['produit_prix'];
            
            $pro_desc = $row_produits['produit_desc'];
            
            $pro_img1 = $row_produits['produit_img1'];
            
            echo "
            
                <div class='col-md-4 col-sm-6 center-responsive'>
                                    
                    <div class='produit'>
                                        
                        <a href='details.php?pro_id=$pro_id'>
                                            
                            <img class='img-responsive' src='administrateur/produit_images/$pro_img1'>
                                            
                        </a>
                                            
                        <div class='text'>
                                            
                            <h3>
                                                
                                <a href='details.php?pro_id=$pro_id'> $pro_titre </a>
                                                
                            </h3>
                                            
                        <p class='prix'>

                            $$pro_prix

                        </p>

                            <p class='buttons'>

                                <a class='btn btn-default' href='details.php?pro_id=$pro_id'>

                                Voir Details

                                </a>

                                <a class='btn btn-primary' href='details.php?pro_id=$pro_id'>

                                <i class='fa fa-shopping-cart'></i> Ajouter au panier

                                </a>

                            </p>
                                            
                        </div>
                                        
                    </div>
                                    
                </div>
            
            ";
            
        }
        
    }
    
}

/// finish getcatpro functions ///

/// finish getRealIpUser functions ///

function items(){
    
    global $bdd;
    
    $ip_add = getRealIpUser();
    
    $get_items = "select * from panier where ip_add='$ip_add'";
    
    $run_items = mysqli_query($bdd,$get_items);
    
    $count_items = mysqli_num_rows($run_items);
    
    echo $count_items;
    
}

/// finish getRealIpUser functions ///

/// begin total_price functions ///

function total_prix(){
    
    global $bdd;
    
    $ip_add = getRealIpUser();
    
    $total = 0;
    
    $select_panier = "select * from panier where ip_add='$ip_add'";
    
    $run_panier = mysqli_query($bdd,$select_panier);
    
    while($record=mysqli_fetch_array($run_panier)){
        
        $pro_id = $record['produit_id'];
        
        $pro_qty = $record['quantite_produit'];
        
        $get_prix = "select * from produits where produit_id='$pro_id'";
        
        $run_prix = mysqli_query($bdd,$get_prix);
        
        while($row_prix=mysqli_fetch_array($run_prix)){
            
            $sub_total = $row_prix['produit_prix']*$pro_qty;
            
            $total += $sub_total;
            
        }
        
    }
    
    echo $total."€";
    
}

/// finish total_price functions ///

?>