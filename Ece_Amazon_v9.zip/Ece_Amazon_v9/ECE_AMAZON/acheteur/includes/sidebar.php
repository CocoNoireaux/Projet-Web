<div class="panel panel-default sidebar-menu"><!--  panel panel-default sidebar-menu Begin  -->
    
    <div class="panel-heading"><!--  panel-heading  Begin  -->
        
        <?php 
        
        $acheteur_session = $_SESSION['acheteur_email'];
        
        $get_acheteur = "select * from acheteurs where acheteur_email='$acheteur_session'";
        
        $run_acheteur = mysqli_query($con,$get_acheteur);
        
        $row_acheteur = mysqli_fetch_array($run_acheteur);
        
        $acheteur_image = $row_acheteur['acheteur_image'];
        
        $acheteur_nom = $row_acheteur['acheteur_nom'];
        
        if(!isset($_SESSION['acheteur_email'])){
            
        }else{
            
            echo "
            
                <center>
                
                    <img src='acheteur_images/$acheteur_image' class='img-responsive' >
                
                </center>
                
                <br/>
                
                <h3 class='panel-title' align='center'>
                
                    Nom: $acheteur_nom
                
                </h3>
            
            ";
            
        }
        
        ?>
        
    </div><!--  panel-heading Finish  -->
    
    <div class="panel-body"><!--  panel-body Begin  -->
        
        <ul class="nav-pills nav-stacked nav"><!--  nav-pills nav-stacked nav Begin  -->
            
            <li class="<?php if(isset($_GET['mes commandes'])){ echo "active"; } ?>">
                
                <a href="mon_compte.php?mes_commandes">
                    
                    <i class="fa fa-list"></i> Mes commandes
                    
                </a>
                
            </li>
            
            <li class="<?php if(isset($_GET['paiement_hors_ligne'])){ echo "active"; } ?>">
                
                <a href="mon_compte.php?paiement_hors_ligne">
                    
                    <i class="fa fa-bolt"></i> Paiement
                    
                </a>
                
            </li>
            
            <li class="<?php if(isset($_GET['modif_compte'])){ echo "active"; } ?>">
                
                <a href="mon_compte.php?modif_compte">
                    
                    <i class="fa fa-pencil"></i> Editer le compte
                    
                </a>
                
            </li>
            
            <li class="<?php if(isset($_GET['change_mdp'])){ echo "active"; } ?>">
                
                <a href="mon_compte.php?change_mdp">
                    
                    <i class="fa fa-user"></i> Changer le mot de passe
                    
                </a>
                
            </li>
            
            <li class="<?php if(isset($_GET['sup_compte'])){ echo "active"; } ?>">
                
                <a href="mon_compte.php?sup_compte">
                    
                    <i class="fa fa-trash-o"></i> Supprimer le compte
                    
                </a>
                
            </li>
            
            <li>
                
                <a href="deconnexion.php">
                    
                    <i class="fa fa-sign-out"></i> Se deconnecter
                    
                </a>
                
            </li>
            
        </ul><!--  nav-pills nav-stacked nav Begin  -->
        
    </div><!--  panel-body Finish  -->
    
</div><!--  panel panel-default sidebar-menu Finish  -->