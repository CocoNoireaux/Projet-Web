<div id="footer"><!-- #footer Begin -->
    <div class="container"><!-- container Begin -->
        <div class="row"><!-- row Begin -->
            <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
               
               <h4>Pages</h4>
                
                <ul><!-- ul Begin -->
                    <li><a href="../panier.php">Mon panier</a></li>
                    <li><a href="../contact.php">Contact Us</a></li>
                    <li><a href="../boutique.php">Boutique</a></li>
                    <li><a href="mon_compte.php">Mon compte</a></li>
                </ul><!-- ul Finish -->
                
                <hr>
                
                <h4>Espace utilisateur</h4>
                
                <ul><!-- ul Begin -->
                           
                           <?php 
                           
                           if(!isset($_SESSION['acheteur_email'])){
                               
                               echo"<a href='../verification.php'>Connexion</a>";
                               
                           }else{
                               
                              echo"<a href='mon_compte.php?mes_commandes'>Mon compte</a>"; 
                               
                           }
                           
                           ?>
                    
                    <li>
                    
                            <?php 
                           
                           if(!isset($_SESSION['acheteur_email'])){
                               
                               echo"<a href='../verification.php'>Connexion</a>";
                               
                           }else{
                               
                              echo"<a href='mon_compte.php?modif_compte'>Editer le compte</a>"; 
                               
                           }
                           
                           ?>
                    
                    </li>
                </ul><!-- ul Finish -->
                
                <hr class="hidden-md hidden-lg hidden-sm">
                
            </div><!-- col-sm-6 col-md-3 Finish -->
            
            <div class="com-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
                
                <h4>Catégories des produits</h4>
                
                <ul><!-- ul Begin -->
                
                    <?php 
                    
                        $get_produit_cats = "select * from categories_produit";
                    
                        $run_produit_cats = mysqli_query($con,$get_produit_cats);
                    
                        while($row_produit_cats=mysqli_fetch_array($run_produit_cats)){
                            
                            $produit_cat_id = $row_produit_cats['produit_cat_id'];
                            
                            $produit_cat_titre = $row_produit_cats['produit_cat_titre'];
                            
                            echo "
                            
                                <li>
                                
                                    <a href='../boutique.php?produit_cat=$produit_cat_id'>
                                    
                                        $produit_cat_titre
                                    
                                    </a>
                                
                                </li>
                            
                            ";
                            
                        }
                    
                    ?>
                
                </ul><!-- ul Finish -->
                
                <hr class="hidden-md hidden-lg">
                
            </div><!-- col-sm-6 col-md-3 Finish -->
            
            <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
                
                <h4>Nos contacts</h4>
                
                <p><!-- p Start -->
                    
                    <strong>Groupe ECE Paris.Lyon</strong>
                    <br/>Immeuble POLLUX
                    <br/>37, Quai de Grenelle 
                    <br/>Tel : 01 44 39 06 00 
                    <br/>contact@ece.fr 
                    <br/><strong>ECE Campus de Paris</strong>
                    
                </p><!-- p Finish -->
                
                <a href="../contact.php">Contactez nous ici</a>
                
                <hr class="hidden-md hidden-lg">
                
            </div><!-- col-sm-6 col-md-3 Finish -->
            
            <div class="col-sm-6 col-md-3">
                
                <h4>Abonnez vous !</h4>
                
                <p class="text-muted">
                    Ne rattez pas nos prochains produits.
                </p>
                
                <form action="https://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('https://feedburner.google.com/fb/a/mailverify?uri=M-devMedia', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true" method="post"><!-- form begin -->
                    <div class="input-group"><!-- input-group begin -->
                        
                        <input type="text" class="form-control" name="email">
                        
                        <input type="hidden" value="M-devMedia" name="uri"/><input type="hidden" name="loc" value="en_US"/>
                        
                        <span class="input-group-btn"><!-- input-group-btn begin -->
                            
                            <input type="submit" value="subscribe" class="btn btn-default">
                            
                        </span><!-- input-group-btn Finish -->
                        
                    </div><!-- input-group Finish -->
                </form><!-- form Finish -->
                
                <hr>
                
                <h4>Partagez sur les réseaux</h4>
                
                <p class="social">
                    <a href="../#" class="fa fa-facebook"></a>
                    <a href="../#" class="fa fa-twitter"></a>
                    <a href="../#" class="fa fa-instagram"></a>
                    <a href="../#" class="fa fa-google-plus"></a>
                    <a href="../#" class="fa fa-envelope"></a>
                </p>
                
            </div>
        </div><!-- row Finish -->
    </div><!-- container Finish -->
</div><!-- #footer Finish -->


<div id="copyright"><!-- #copyright Begin -->
    <div class="container"><!-- container Begin -->
        <div class="col-md-6"><!-- col-md-6 Begin -->
            
            <p class="pull-left">&copy; 2019 ECE Paris.Lyon All Rights Reserv</p>
            
        </div><!-- col-md-6 Finish -->
        
    </div><!-- container Finish -->
</div><!-- #copyright Finish -->