<?php 

$acheteur_session = $_SESSION['acheteur_email'];

$get_acheteur = "select * from acheteurs where acheteur_email='$acheteur_session'";

$run_acheteur = mysqli_query($con,$get_acheteur);

$row_acheteur = mysqli_fetch_array($run_acheteur);

$acheteur_id = $row_acheteur['acheteur_id'];

$acheteur_nom = $row_acheteur['acheteur_nom'];

$acheteur_email = $row_acheteur['acheteur_email'];

$acheteur_pays = $row_acheteur['acheteur_pays'];

$acheteur_ville = $row_acheteur['acheteur_ville'];

$acheteur_contact = $row_acheteur['acheteur_contact'];

$acheteur_adresse = $row_acheteur['acheteur_adresse'];

$acheteur_image = $row_acheteur['acheteur_image'];

?>

<h1 align="center"> Editer votre compte </h1>

<form action="" method="post" enctype="multipart/form-data"><!-- form Begin -->
    
    <div class="form-group"><!-- form-group Begin -->
        
        <label>Prenom Nom: </label>
        
        <input type="text" name="c_name" class="form-control" value="<?php echo $acheteur_nom; ?>" required>
        
    </div><!-- form-group Finish -->
    
    <div class="form-group"><!-- form-group Begin -->
        
        <label> Email: </label>
        
        <input type="text" name="c_email" class="form-control" value="<?php echo $acheteur_email; ?>" required>
        
    </div><!-- form-group Finish -->
    
    <div class="form-group"><!-- form-group Begin -->
        
        <label> Pays: </label>
        
        <input type="text" name="c_country" class="form-control" value="<?php echo $acheteur_pays; ?>" required>
        
    </div><!-- form-group Finish -->
    
    <div class="form-group"><!-- form-group Begin -->
        
        <label> Ville: </label>
        
        <input type="text" name="c_city" class="form-control" value="<?php echo $acheteur_ville; ?>" required>
        
    </div><!-- form-group Finish -->
    
    <div class="form-group"><!-- form-group Begin -->
        
        <label> Telephone: </label>
        
        <input type="text" name="c_contact" class="form-control" value="<?php echo $acheteur_contact; ?>" required>
        
    </div><!-- form-group Finish -->
    
    <div class="form-group"><!-- form-group Begin -->
        
        <label> Adresse: </label>
        
        <input type="text" name="c_address" class="form-control" value="<?php echo $acheteur_adresse; ?>" required>
        
    </div><!-- form-group Finish -->
    
    <div class="form-group"><!-- form-group Begin -->
        
        <label> Photo de profil: </label>
        
        <input type="file" name="c_image" class="form-control form-height-custom">
        
        <img class="img-responsive" src="acheteur_images/<?php echo $acheteur_image; ?>" alt="Acheteur Image">
        
    </div><!-- form-group Finish -->
    
    <div class="text-center"><!-- text-center Begin -->
        
        <button name="update" class="btn btn-primary"><!-- btn btn-primary Begin -->
            
            <i class="fa fa-user-md"></i> Valider
            
        </button><!-- btn btn-primary inish -->
        
    </div><!-- text-center Finish -->
    
</form><!-- form Finish -->

<?php 

if(isset($_POST['update'])){
    
    $update_id = $acheteur_id;
    
    $c_name = $_POST['c_name'];
    
    $c_email = $_POST['c_email'];
    
    $c_country = $_POST['c_country'];
    
    $c_city = $_POST['c_city'];
    
    $c_address = $_POST['c_address'];
    
    $c_contact = $_POST['c_contact'];
    
    $c_image = $_FILES['c_image']['name'];
    
    $c_image_tmp = $_FILES['c_image']['tmp_name'];
    
    move_uploaded_file ($c_image_tmp,"acheteur_images/$c_image");
    
    $update_acheteur = "update acheteurs set acheteur_nom='$c_name',acheteur_email='$c_email',acheteur_pays='$c_country',acheteur_ville='$c_city',acheteur_adresse='$c_address',acheteur_contact='$c_contact',acheteur_image='$c_image' where acheteur_id='$update_id' ";
    
    $run_acheteur = mysqli_query($con,$update_acheteur);
    
    if($run_acheteur){
        
        echo "<script>alert('Your account has been edited, to complete the process, please Relogin')</script>";
        
        echo "<script>window.open('deconnexion.php','_self')</script>";
        
    }
    
}

?>