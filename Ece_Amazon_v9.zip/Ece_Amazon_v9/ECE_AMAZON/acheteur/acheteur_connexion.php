<div class="box"><!-- box Begin -->
    
  <div class="box-header"><!-- box-header Begin -->
      
      <center><!-- center Begin -->
          
          <h1> Connexion </h1>
          
          <p class="lead"> Avez vous déjà un compte ? </p>
          
          <p class="text-muted"> Identifiez-vous </p>
          
      </center><!-- center Finish -->
      
  </div><!-- box-header Finish -->
   
  <form method="post" action="verification.php"><!-- form Begin -->
      
      <div class="form-group"><!-- form-group Begin -->
          
          <label> Email </label>
          
          <input name="c_email" type="text" class="form-control" required>
          
      </div><!-- form-group Finish -->
      
       <div class="form-group"><!-- form-group Begin -->
          
          <label> Mot de Passe </label>
          
          <input name="c_pass" type="password" class="form-control" required>
          
      </div><!-- form-group Finish -->
      
      <div class="text-center"><!-- text-center Begin -->
          
          <button name="login" value="Login" class="btn btn-primary">
              
              <i class="fa fa-sign-in"></i> se connecter
              
          </button>
          
      </div><!-- text-center Finish -->     
      
  </form><!-- form Finish -->
   
  <center><!-- center Begin -->
      
     <a href="enregistrement_acheteur.php">
         
         <h3> Si vous n'avez pas déjà un compte, inscrivez vous ici !</h3>
         
     </a> 
      
  </center><!-- center Finish -->
    
</div><!-- box Finish -->


<?php 

if(isset($_POST['login'])){
    
    $acheteur_email = $_POST['c_email'];
    
    $acheteur_pass = $_POST['c_pass'];
    
    $select_acheteur = "select * from acheteurs where acheteur_email='$acheteur_email' AND acheteur_mdp='$acheteur_mdp'";
    
    $run_acheteur = mysqli_query($con,$select_acheteur);
    
    $get_ip = getRealIpUser();
    
    $check_acheteur = mysqli_num_rows($run_acheteur);
    
    $select_panier = "select * from panier where ip_add='$get_ip'";
    
    $run_panier = mysqli_query($con,$select_panier);
    
    $check_panier = mysqli_num_rows($run_panier);
    
    if($check_acheteur==0){
        
        echo "<script>alert('Votre email ou mot de passe est faux')</script>";
        
        exit();
        
    }
    
    if($check_acheteur==1 AND $check_panier==0){
        
        $_SESSION['acheteur_email']=$acheteur_email;
        
       echo "<script>alert('Vous êtes connecté')</script>"; 
        
       echo "<script>window.open('acheteur/mon_compte.php?mes_commandes','_self')</script>";
        
    }else{
        
        $_SESSION['acheteur_email']=$acheteur_email;
        
       echo "<script>alert('Vous êtes connecté')</script>"; 
        
       echo "<script>window.open('verification.php','_self')</script>";
        
    }
    
}

?>