<center><!--  center Begin  -->
    
    <h1> Mes commandes </h1>
    
    <p class="lead"> Toutes cos commandes en cours sont ici</p>
    
    <p class="text-muted">
        
        Si vous avez des questions, n'hésitez pas à <a href="../contact.php">nous contacter</a>. Notre service client fonctionne <strong>24/7</strong>
        
    </p>
    
</center><!--  center Finish  -->


<hr>


<div class="table-responsive"><!--  table-responsive Begin  -->
    
    <table class="table table-bordered table-hover"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
            <tr><!--  tr Begin  -->
                
                <th> n°: </th>
                <th> Prix: </th>
                <th> Facture n°: </th>
                <th> Qté: </th>
                <th> Taille: </th>
                <th> Date :</th>
                <th> Payé / non payé: </th>
                <th> Statut: </th>
                
            </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
           
           <?php 
            
            $acheteur_session = $_SESSION['acheteur_email'];
            
            $get_acheteur = "select * from acheteurs where acheteur_email='$acheteur_session'";
            
            $run_acheteur = mysqli_query($con,$get_acheteur);
            
            $row_acheteur = mysqli_fetch_array($run_acheteur);
            
            $acheteur_id = $row_acheteur['acheteur_id'];
            
            $get_commandes = "select * from commandes where acheteur_id='$acheteur_id'";
            
            $run_commandes = mysqli_query($con,$get_commandes);
            
            $i = 0;
            
            while($row_commandes = mysqli_fetch_array($run_commandes)){
                
                $commande_id = $row_commandes['commande_id'];
                
                $montant_du = $row_commandes['montant_du'];
                
                $invoice_no = $row_commandes['n°facture'];
                
                $qty = $row_commandes['quantite_produit'];
                
                $size = $row_orders['taille'];
                
                $commande_date = substr($row_commandes['commande_date'],0,11);
                
                $commande_statut = $row_commandes['commande_statut'];
                
                $i++;
                
                if($commande_statut=='attente'){
                    
                    $commande_statut = 'Inpayé';
                    
                }else{
                    
                    $commande_statut = 'Payé';
                    
                }
            
            ?>
            
            <tr><!--  tr Begin  -->
                
                <th> <?php echo $i; ?> </th>
                <td> $<?php echo $montant_du; ?> </td>
                <td> <?php echo $invoice_no; ?> </td>
                <td> <?php echo $qty; ?> </td>
                <td> <?php echo $size; ?> </td>
                <td> <?php echo $commande_date; ?> </td>
                <td> <?php echo $commande_statut; ?> </td>
                
                <td>
                    
                    <a href="confirm.php?order_id=<?php echo $commande_id; ?>" target="_blank" class="btn btn-primary btn-sm"> Confirmer paiement </a>
                    
                </td>
                
            </tr><!--  tr Finish  -->
            
            <?php } ?>
            
        </tbody><!--  tbody Finish  -->
        
    </table><!--  table table-bordered table-hover Finish  -->
    
</div><!--  table-responsive Finish  -->