<?php 

    $active='Cart'; //permet de surligner le menu panier sur le site pour plus de clarté
    include("includes/header.php");

?>
   
   <div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Accueil</a>
                   </li>
                   <li>
                       Mon panier
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->
           
           <div id="cart" class="col-md-9"><!-- col-md-9 Begin -->
               
               <div class="box"><!-- box Begin -->
                   
                   <form action="panier.php" method="post" enctype="multipart/form-data"><!-- form Begin -->
                       
                       <h1>Mon panier</h1>
                       
                       <?php 
                       
                       $ip_add = getRealIpUser();
                       
                       $select_panier = "select * from panier where ip_add='$ip_add'";
                       
                       $run_panier = mysqli_query($con,$select_panier);
                       
                       $count = mysqli_num_rows($run_panier);
                       
                       ?>
                       
                       <p class="text-muted">Vous avez actuellement <?php echo $count; ?> produits dans votre panier</p>
                       
                       <div class="table-responsive"><!-- table-responsive Begin -->
                           
                           <table class="table"><!-- table Begin -->
                               
                               <thead><!-- thead Begin -->
                                   
                                   <tr><!-- tr Begin -->
                                       
                                       <th colspan="2">Produit</th>
                                       <th>Quantité</th>
                                       <th>Prix à l'unité</th>
                                       <th>Taille</th>
                                       <th colspan="1">Supprimer</th>
                                       <th colspan="2">Prix</th>
                                       
                                   </tr><!-- tr Finish -->
                                   
                               </thead><!-- thead Finish -->
                               
                               <tbody><!-- tbody Begin -->
                                  
                                  <?php 
                                   
                                   $total = 0;
                                   
                                   while($row_panier = mysqli_fetch_array($run_panier)){
                                       
                                     $pro_id = $row_panier['produit_id'];
                                       
                                     $pro_size = $row_panier['taille'];
                                       
                                     $pro_qty = $row_panier['quantite_produit'];
                                       
                                       $get_produits = "select * from produits where produit_id='$pro_id'";
                                       
                                       $run_produits = mysqli_query($con,$get_produits);
                                       
                                       while($row_produits = mysqli_fetch_array($run_produits)){
                                           
                                           $produit_titre = $row_produits['produit_titre'];
                                           
                                           $produit_img1 = $row_produits['produit_img1'];
                                           
                                           $only_prix = $row_produits['produit_prix'];
                                           
                                           $sub_total = $row_produits['produit_price']*$pro_qty;
                                           
                                           $total += $sub_total;
                                           
                                   ?>
                                   
                                   <tr><!-- tr Begin -->
                                       
                                       <td>
                                           
                                           <img class="img-responsive" src="administrateur/produit_images/<?php echo $produit_img1; ?>" alt="produit 3a">
                                           
                                       </td>
                                       
                                       <td>
                                           
                                           <a href="details.php?pro_id=<?php echo $pro_id; ?>"> <?php echo $produit_titre; ?> </a>
                                           
                                       </td>
                                       
                                       <td>
                                          
                                           <?php echo $pro_qty; ?>
                                           
                                       </td>
                                       
                                       <td>
                                           
                                           <?php echo $only_prix; ?>
                                           
                                       </td>
                                       
                                       <td>
                                           
                                           <?php echo $pro_size; ?>
                                           
                                       </td>
                                       
                                       <td>
                                           
                                           <input type="checkbox" name="remove[]" value="<?php echo $pro_id; ?>">
                                           
                                       </td>
                                       
                                       <td>
                                           
                                           $<?php echo $sub_total; ?>
                                           
                                       </td>
                                       
                                   </tr><!-- tr Finish -->
                                   
                                   <?php } } ?>
                                   
                               </tbody><!-- tbody Finish -->
                               
                               <tfoot><!-- tfoot Begin -->
                                   
                                   <tr><!-- tr Begin -->
                                       
                                       <th colspan="5">Total</th>
                                       <th colspan="2">$<?php echo $total; ?></th>
                                       
                                   </tr><!-- tr Finish -->
                                   
                               </tfoot><!-- tfoot Finish -->
                               
                           </table><!-- table Finish -->
                           
                       </div><!-- table-responsive Finish -->
                       
                       <div class="box-footer"><!-- box-footer Begin -->
                           
                           <div class="pull-left"><!-- pull-left Begin -->
                               
                               <a href="index.php" class="btn btn-default"><!-- btn btn-default Begin -->
                                   
                                   <i class="fa fa-chevron-left"></i> Faire d'autres achats
                                   
                               </a><!-- btn btn-default Finish -->
                               
                           </div><!-- pull-left Finish -->
                           
                           <div class="pull-right"><!-- pull-right Begin -->
                               
                               <button type="submit" name="update" value="Update Cart" class="btn btn-default"><!-- btn btn-default Begin -->
                                   
                                   <i class="fa fa-refresh"></i> Supprimer du pannier
                                   
                               </button><!-- btn btn-default Finish -->
                               
                               <a href="verification.php" class="btn btn-primary">
                                   
                                   Passer la commande <i class="fa fa-chevron-right"></i>
                                   
                               </a>
                               
                           </div><!-- pull-right Finish -->
                           
                       </div><!-- box-footer Finish -->
                       
                   </form><!-- form Finish -->
                   
               </div><!-- box Finish -->
               
               <?php 
               
                function update_cart(){ //Supprime les produits cochés 
                    
                    global $con;
                    
                    if(isset($_POST['update'])){
                        
                        foreach($_POST['remove'] as $remove_id){
                            
                            $delete_produit = "delete from panier where produit_id='$remove_id'";
                            
                            $run_delete = mysqli_query($con,$delete_produit);
                            
                            if($run_delete){
                                
                                echo "<script>window.open('panier.php','_self')</script>"; //Reaffiche le panier mis a jour
                                
                            }
                            
                        }
                        
                    }
                    
                }
               
               echo @$up_cart = update_cart();
               
               ?>
               
               <div id="row same-heigh-row"><!-- #row same-heigh-row Begin -->
                   <div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Begin -->
                       <div class="box same-height headline"><!-- box same-height headline Begin -->
                           <h3 class="text-center">Produits que vous pouriez aimer :</h3>
                       </div><!-- box same-height headline Finish -->
                   </div><!-- col-md-3 col-sm-6 Finish -->
                   
                   <?php 
                   
                   $get_produits = "select * from produits order by rand() LIMIT 0,3";
                   
                   $run_produits = mysqli_query($con,$get_produits);
                   
                   while($row_produits=mysqli_fetch_array($run_produits)){
                       
                       $pro_id = $row_produits['produit_id'];
                       
                       $pro_titre = $row_produits['produit_titre'];
                       
                       $pro_prix = $row_produits['produit_prix'];
                       
                       $pro_img1 = $row_produits['produit_img1'];
                       
                       echo "
                       
                    <div class='col-md-3 col-sm-6 center-responsive'><!-- col-md-3 col-sm-6 center-responsive Begin -->
                       <div class='produit same-height'><!-- produit same-height Begin -->
                           <a href='details.php?pro_id=$pro_id'>
                               <img class='img-responsive' src='administrateur/produit_images/$pro_img1' alt='produit 6'>
                            </a>
                            
                            <div class='text'><!-- text Begin -->
                                <h3><a href='details.php?pro_id=$pro_id'> $pro_titre </a></h3>
                                
                                <p class='price'>$$pro_prix</p>
                                
                            </div><!-- text Finish -->
                            
                        </div><!-- produit same-height Finish -->
                   </div><!-- col-md-3 col-sm-6 center-responsive Finish -->
                   
                       ";
                       
                   }
                   
                   ?>
                   
               </div><!-- #row same-heigh-row Finish -->
               
           </div><!-- col-md-9 Finish -->
           
           <div class="col-md-3"><!-- col-md-3 Begin -->
               
               <div id="order-summary" class="box"><!-- box Begin -->
                   
                   <div class="box-header"><!-- box-header Begin -->
                       
                       <h3>Recapitulatif</h3>
                       
                   </div><!-- box-header Finish -->
                   
                   <p class="text-muted"><!-- text-muted Begin -->
                       
                       Votre commande est éligible à la livraison Standard gratuite en France métropolitaine. 
                       
                   </p><!-- text-muted Finish -->
                   
                   <div class="table-responsive"><!-- table-responsive Begin -->
                       
                       <table class="table"><!-- table Begin -->
                           
                           <tbody><!-- tbody Begin -->
                               
                               <tr><!-- tr Begin -->
                                   
                                   <td> Prix commande </td>
                                   <th> $<?php echo $total; ?> </th>
                                   
                               </tr><!-- tr Finish -->
                               
                               <tr><!-- tr Begin -->
                                   
                                   <td> Frais d'expédition et de manutention </td>
                                   <td> $0 </td>
                                   
                               </tr><!-- tr Finish -->
                               
                               <tr><!-- tr Begin -->
                                   
                                   <td> Taxe </td>
                                   <th> $0 </th>
                                   
                               </tr><!-- tr Finish -->
                               
                               <tr class="total"><!-- tr Begin -->
                                   
                                   <td> Total </td>
                                   <th> $<?php echo $total; ?> </th>
                                   
                               </tr><!-- tr Finish -->
                               
                           </tbody><!-- tbody Finish -->
                           
                       </table><!-- table Finish -->
                       
                   </div><!-- table-responsive Finish -->
                   
               </div><!-- box Finish -->
               
           </div><!-- col-md-3 Finish -->
           
       </div><!-- container Finish -->
   </div><!-- #content Finish -->
   
   <?php 
    
    include("includes/footer.php");
    
    ?>
    
    <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
    
    
</body>
</html>