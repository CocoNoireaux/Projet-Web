<?php 

session_start();

include("includes/bdd.php");
include("fonctions/fonctions.php");

?>

<?php 

if(isset($_GET['pro_id'])){
    
    $produit_id = $_GET['pro_id'];
    
    $get_produit = "select * from produits where produit_id='$produit_id'";
    
    $run_produit = mysqli_query($con,$get_produit);
    
    $row_produit = mysqli_fetch_array($run_produit);
    
    $p_cat_id = $row_produit['produit_cat_id'];
    
    $pro_titre = $row_produit['produit_titre'];
    
    $pro_prix = $row_produit['produit_prix'];
    
    $pro_desc = $row_produit['produit_desc'];
    
    $pro_img1 = $row_produit['produit_img1'];
    
    $pro_img2 = $row_produit['produit_img2'];
    
    $pro_img3 = $row_produit['produit_img3'];
    
    $pro_video = $row_produit['produit_video'];
    
    $get_p_cat = "select * from categories_produit where produit_cat_id='$p_cat_id'";
    
    $run_p_cat = mysqli_query($con,$get_p_cat);
    
    $row_p_cat = mysqli_fetch_array($run_p_cat);
    
    $p_cat_titre = $row_p_cat['produit_cat_titre'];
    
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ECE Amazon</title>
    <link rel="stylesheet" href="styles/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="styles/style.css">
</head>
<body>
   
   <div id="top"><!-- Top Begin -->
       
       <div class="container"><!-- container Begin -->
           
           <div class="col-md-6 offer"><!-- col-md-6 offer Begin -->
               
               <a href="#" class="btn btn-success btn-sm">
                   
                   <?php 
                   
                   if(!isset($_SESSION['acheteur_email'])){
                       
                       echo "Bienvenue: Invité";
                       
                   }else{
                       
                       echo "Bienvenue: " . $_SESSION['acheteur_email'] . "";
                       
                   }
                   
                   ?>
                   
               </a>
               <a href="verification.php"><?php items(); ?> Produits dans votre panier | Prix total: <?php total_prix(); ?> </a>
               
           </div><!-- col-md-6 offer Finish -->
           
           <div class="col-md-6"><!-- col-md-6 Begin -->
               
               <ul class="menu"><!-- cmenu Begin -->
                   
                   <li>
                       <a href="administrateur/index.php">Admin</a>
                   </li>
                   <li>
                       <a href="enregistrement_acheteur.php">S'inscrire</a>
                   </li>
                   <li>
                       <a href="verification.php">Mon compte</a>
                   </li>
                   <li>
                       <a href="panier.php">Mon panier</a>
                   </li>
                   <li>
                       <a href="verification.php">
                           
                           <?php 
                           
                           if(!isset($_SESSION['acheteur_email'])){
                       
                                echo "<a href='verification.php'> Se connecter </a>";

                               }else{

                                echo " <a href='deconnexion.php'> Se deconnecter </a> ";

                               }
                           
                           ?>
                           
                       </a>
                   </li>
                   
               </ul><!-- menu Finish -->
               
           </div><!-- col-md-6 Finish -->
           
       </div><!-- container Finish -->
       
   </div><!-- Top Finish -->
   
   <div id="navbar" class="navbar navbar-default"><!-- navbar navbar-default Begin -->
       
       <div class="container"><!-- container Begin -->
           
           <div class="navbar-header"><!-- navbar-header Begin -->
               
               <a href="index.php" class="navbar-brand home"><!-- navbar-brand home Begin -->
                
                   <br>ECE Amazon   
                   
                         
               </a><!-- navbar-brand home Finish -->
               
               <button class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                   
                   <span class="sr-only">Toggle Navigation</span>
                   
                   <i class="fa fa-align-justify"></i>
                   
               </button>
               
               <button class="navbar-toggle" data-toggle="collapse" data-target="#search">
                   
                   <span class="sr-only">Toggle Search</span>
                   
                   <i class="fa fa-search"></i>
                   
               </button>
               
           </div><!-- navbar-header Finish -->
           
           <div class="navbar-collapse collapse" id="navigation"><!-- navbar-collapse collapse Begin -->
               
               <div class="padding-nav"><!-- padding-nav Begin -->
                   
                   <ul class="nav navbar-nav left"><!-- nav navbar-nav left Begin -->
                       
                       <li class="<?php if($active=='Home') echo"active"; ?>"> <!-- permet de montrer l'ombre de l'onglet activé -->
                           <a href="index.php">Accueil</a>
                       </li>
                       <li class="<?php if($active=='Shop') echo"active"; ?>">
                           <a href="boutique.php">Boutique</a>
                       </li>
                       <li class="<?php if($active=='Account') echo"active"; ?>">
                           
                           <?php 
                           
                           if(!isset($_SESSION['acheteur_email'])){
                               
                               echo"<a href='verification.php'>Mon compte</a>";
                               
                           }else{
                               
                              echo"<a href='acheteur/mon_compte.php?mes_commandes'>Mon compte</a>"; 
                               
                           }
                           
                           ?>
                           
                       </li>
                       <li class="<?php if($active=='Cart') echo"active"; ?>">
                           <a href="panier.php">Mon panier</a>
                       </li>
                       <li class="<?php if($active=='Contact') echo"active"; ?>">
                           <a href="contact.php">Contactez nous</a>
                       </li>
                       
                       
                       
                   </ul><!-- nav navbar-nav left Finish -->
                   
               </div><!-- padding-nav Finish -->
               
               <a href="panier.php" class="btn navbar-btn btn-primary right"><!-- btn navbar-btn btn-primary Begin -->
                   
                   <i class="fa fa-shopping-cart"></i>
                   
                   <span><?php items(); ?> Produits dans votre panier</span>
                   
               </a><!-- btn navbar-btn btn-primary Finish -->
               
               <div class="navbar-collapse collapse right"><!-- navbar-collapse collapse right Begin -->
                   
                   <button class="btn btn-primary navbar-btn" type="button" data-toggle="collapse" data-target="#search"><!-- btn btn-primary navbar-btn Begin -->
                       
                       <span class="sr-only">Toggle Search</span>
                       
                       <i class="fa fa-search"></i>
                       
                   </button><!-- btn btn-primary navbar-btn Finish -->
                   
               </div><!-- navbar-collapse collapse right Finish -->
               
               <div class="collapse clearfix" id="search"><!-- collapse clearfix Begin -->
                   
                   <form method="get" action="results.php" class="navbar-form"><!-- navbar-form Begin -->
                       
                       <div class="input-group"><!-- input-group Begin -->
                           
                           <input type="text" class="form-control" placeholder="Search" name="user_query" required>
                           
                           <span class="input-group-btn"><!-- input-group-btn Begin -->
                           
                           <button type="submit" name="search" value="Search" class="btn btn-primary"><!-- btn btn-primary Begin -->
                               
                               <i class="fa fa-search"></i>
                               
                           </button><!-- btn btn-primary Finish -->
                           
                           </span><!-- input-group-btn Finish -->
                           
                       </div><!-- input-group Finish -->
                       
                   </form><!-- navbar-form Finish -->
                   
               </div><!-- collapse clearfix Finish -->
               
           </div><!-- navbar-collapse collapse Finish -->
           
       </div><!-- container Finish -->
       
   </div><!-- navbar navbar-default Finish -->