<div class="box"><!-- box Begin -->
   
   <?php 
    
    $session_email = $_SESSION['acheteur_email'];
    
    $select_acheteur = "select * from acheteurs where acheteur_email='$session_email'";
    
    $run_acheteur = mysqli_query($con,$select_acheteur);
    
    $row_acheteur = mysqli_fetch_array($run_acheteur);
    
    $acheteur_id = $row_acheteur['acheteur_id'];
    
    ?>
    
    <h1 class="text-center">Payment Options For You</h1>  
    
     <p class="lead text-center"><!-- lead text-center Begin -->
         
         <a href="commandes.php?c_id=<?php echo $acheteur_id ?>"> Offline Payment </a>
         
     </p><!-- lead text-center Finish -->
     
     <center><!-- center Begin -->
         
        <p class="lead"><!-- lead Begin -->
            
            <a href="#">
                
                Paypall Payment
                
                <img class="img-responsive" src="images/paypall_img.png" alt="img-paypall">
                
            </a>
            
        </p> <!-- lead Finish -->
         
     </center><!-- center Finish -->
    
</div><!-- box Finish -->