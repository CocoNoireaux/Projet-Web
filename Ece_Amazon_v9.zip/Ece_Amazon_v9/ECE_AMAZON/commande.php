<?php 

include("includes/bdd.php");
include("fonctions/fonctions.php");

?>
<?php 

if(isset($_GET['c_id'])){
    
    $acheteur_id = $_GET['c_id'];
    
}

$ip_add = getRealIpUser();

$status = "pending";

$invoice_no = mt_rand();

$select_panier = "select * from panier where ip_add='$ip_add'";

$run_panier = mysqli_query($con,$select_panier);

while($row_panier = mysqli_fetch_array($run_panier)){
    
    $pro_id = $row_panier['produit_id'];
    
    $pro_qty = $row_panier['quantite_produit'];
    
    $pro_size = $row_panier['taille'];
    
    $get_produits = "select * from produits where produit_id='$pro_id'";
    
    $run_produits = mysqli_query($con,$get_produits);
    
    while($row_produits = mysqli_fetch_array($run_produits)){
        
        $sub_total = $row_produits['produit_prix']*$pro_qty;
        
        $insert_acheteur_commande = "insert into commandes (acheteur_id,montant_du,n°facture,quantite_produit,taille,commande_date,commande_statut) values ('$acheteur_id','$sub_total','$invoice_no','$pro_qty','$pro_size',NOW(),'$status')";
        
        $run_acheteur_commande = mysqli_query($con,$insert_acheteur_commande);
        
        $insert_pending_commande = "insert into commandes_attentes (acheteur_id,n°facture,produit_id,quantite_produit,taille,commande_statut) values ('$acheteur_id','$invoice_no','$pro_id','$pro_qty','$pro_size','$status')";
        
        $run_pending_commande = mysqli_query($con,$insert_pending_commande);
        
        $delete_panier = "delete from panier where ip_add='$ip_add'";
        
        $run_delete = mysqli_query($con,$delete_panier);
        
        echo "<script>alert('Vos commandes ont été soumises, merci')</script>";
        
        echo "<script>window.open('acheteur/mon_compte.php?mes_commandes','_self')</script>";
        
    }
    
}

?>