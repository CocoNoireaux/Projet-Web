<!-- affichage côté page web -->

<div class="panel panel-default sidebar-menu">
    
    <div class="panel-heading">
        
        <?php 
        
        $vendeur_session = $_SESSION['vendeur_email'];
        
        $get_vendeur = "select * from vendeur where vendeur_email='$customer_session'";
        
        $run_vendeur = mysqli_query($con,$get_vendeur);
        
        $row_vendeur = mysqli_fetch_array($run_vendeur);
        
        $vendeur_image = $row_vendeur['vendeur_image'];
        
        $vendeur_name = $row_vendeur['vendeur_name'];
        
        if(!isset($_SESSION['vendeur_email'])){
            
        }else{
            
            echo "
            
                <center>
                
                    <img src='vendeurs_images/$vendeur_image' class='img-responsive' >
                
                </center>
                
                <br/>
                
                <h3 class='panel-title' align='center'>
                
                    Nom: $vendeur_name
                
                </h3>
            
            ";
            
        }
        
        ?>
        
    </div>
    
    <div class="panel-body">
        
        <ul class="nav-pills nav-stacked nav">>
            
            
            <li class="<?php if(isset($_GET['pay_offline'])){ echo "active"; } ?>">
                
                <a href="my_account.php?insert_product">
                    
                    <i class="fa fa-pencil"></i> Ajouter un produit a vendre
                    
                </a>
                
            </li>
            
            <li class="<?php if(isset($_GET['edit_account'])){ echo "active"; } ?>">
                
                <a href="my_account.php?edit_account">
                    
                    <i class="fa fa-list"></i> Mes produits en ventes
                    
                </a>
                
            </li>
            
            
            
        </ul>
        
    </div>
    
</div>