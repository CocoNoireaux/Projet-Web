<?php 

$con = mysqli_connect("localhost","root","","ecom_store");

?>

<!-- connexion avec la base de donnée -->