
<!-- Affichage du haut de la page web -->
<?php 

session_start();

include("includes/db.php");
include("functions/functions.php");

?>

<?php 

if(isset($_GET['pro_id'])){
    
    $product_id = $_GET['pro_id'];
    
    $get_product = "select * from products where product_id='$product_id'"; // Accès à la table produits, récupération des données
    
    $run_product = mysqli_query($con,$get_product);
    
    $row_product = mysqli_fetch_array($run_product);
    
    $p_cat_id = $row_product['p_cat_id'];
    
    $pro_title = $row_product['product_title'];
    
    $pro_price = $row_product['product_price'];
    
    $pro_desc = $row_product['product_desc'];
    
    $pro_img1 = $row_product['product_img1'];
    
    $pro_img2 = $row_product['product_img2'];
    
    $pro_img3 = $row_product['product_img3'];
    
    $pro_video = $row_product['product_video'];
    
    $get_p_cat = "select * from product_categories where p_cat_id='$p_cat_id'"; // Accès à la table catégories_produit, récupération des données
    
    $run_p_cat = mysqli_query($con,$get_p_cat);
    
    $row_p_cat = mysqli_fetch_array($run_p_cat);
    
    $p_cat_title = $row_p_cat['p_cat_title'];
    
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ECE Amazon</title>
    <link rel="stylesheet" href="styles/bootstrap-337.min.css"> <!-- Bibliothèque Bootstrap -->
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css"> <!-- Bibliothèque css -->
    <link rel="stylesheet" href="styles/style.css"> <!-- Bibliothèque css -->
</head>
<body>
   
   <div id="top">
       
       <div class="container"><!-- Début container -->
           
           <div class="col-md-6 offer">
               
               <a href="#" class="btn btn-success btn-sm">
                   
                   <?php 
                   
                   if(!isset($_SESSION['customer_email'])){
                       
                       echo "Bienvenue: Invité";
                       
                   }else{
                       
                       echo "Bienvenue: " . $_SESSION['customer_email'] . "";
                       
                   }
                   
                   ?>
                   
               </a>
               <a href="cart.php"><?php items(); ?> Produits dans votre panier | Prix total: <?php total_price(); ?> </a>
               
           </div>
           
           <div class="col-md-6">
               
               <ul class="menu"><!-- Début du menu -->
                   
                   <li>
                       <a href="admin_area/index.php">Admin</a>
                   </li>
                   <li>
                       <a href="customer_register.php">S'inscrire</a>
                   </li>
                   <li>
                       <a href="checkout.php">Mon compte</a>
                   </li>
                   <li>
                       <a href="cart.php">Mon panier</a>
                   </li>
                   <li>
                       <a href="checkout.php">
                           
                           <?php 
                           
                           if(!isset($_SESSION['customer_email'])){
                       
                                echo "<a href='checkout.php'> Se connecter </a>";

                               }else{

                                echo " <a href='logout.php'> Se deconnecter </a> ";

                               }
                           
                           ?>
                           
                       </a>
                   </li>
                   
               </ul><!-- Fin menu -->
               
           </div>
           
       </div><!-- Fin container -->
       
   </div>
   
   <div id="navbar" class="navbar navbar-default">
       
       <div class="container"><!-- Début container -->
           
           <div class="navbar-header">
               
               <a href="index.php" class="navbar-brand home"> <!-- Début barre d'accueil -->
                
                   <br>ECE Amazon   
                   
                         
               </a>
               
               <button class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                   
                   <span class="sr-only">Toggle Navigation</span>
                   
                   <i class="fa fa-align-justify"></i>
                   
               </button>
               
               <button class="navbar-toggle" data-toggle="collapse" data-target="#search"> <!-- Barre de recherche -->
                   
                   <span class="sr-only">Toggle Search</span>
                   
                   <i class="fa fa-search"></i>
                   
               </button>
               
           </div>
           
           <div class="navbar-collapse collapse" id="navigation">
               
               <div class="padding-nav">
                   
                   <ul class="nav navbar-nav left">
                       
                       <li class="<?php if($active=='Home') echo"active"; ?>"> <!-- Permet de montrer l'ombre de l'onglet activé -->
                           <a href="index.php">Accueil</a>
                       </li>
                       <li class="<?php if($active=='Shop') echo"active"; ?>">
                           <a href="shop.php">Boutique</a>
                       </li>
                       <li class="<?php if($active=='Account') echo"active"; ?>">
                           
                           <?php 
                           
                           if(!isset($_SESSION['customer_email'])){
                               
                               echo"<a href='checkout.php'>Mon Compte</a>";
                               
                           }else{
                               
                              echo"<a href='customer/my_account.php?my_orders'>Mon Compte</a>"; 
                               
                           }
                           
                           ?>
                           
                       </li>
                       <li class="<?php if($active=='vente_flash') echo"active"; ?>">
                           <a href="vente_flash.php">Vente Flash</a>
                       </li>
                       <li class="<?php if($active=='Cart') echo"active"; ?>">
                           <a href="cart.php">Mon panier</a>
                       </li>
                       
                       <li class="<?php if($active=='vendre') echo"active"; ?>">
                           
                           <?php 
                           
                           if(!isset($_SESSION['customer_email'])){
                               
                               echo"<a href='checkout.php'>Vendre</a>";
                               
                           }else{
                               
                              echo"<a href='vendre/my_account.php?edit_account'>Vendre</a>"; 
                               
                           }
                           
                           ?>
                           
                       </li>
                       
                       
                       
                   </ul>
                   
               </div>
               
               <a href="cart.php" class="btn navbar-btn btn-primary right">
                   
                   <i class="fa fa-shopping-cart"></i>
                   
                   <span><?php items(); ?> Produits dans votre panier</span>
                   
               </a>
               
               <div class="navbar-collapse collapse right">
                   
                   <button class="btn btn-primary navbar-btn" type="button" data-toggle="collapse" data-target="#search">
                       
                       <span class="sr-only">Toggle Search</span>
                       
                       <i class="fa fa-search"></i>
                       
                   </button>
                   
               </div>
               
               <div class="collapse clearfix" id="search">
                   
                   <form method="get" action="results.php" class="navbar-form">
                       
                       <div class="input-group">
                           
                           <input type="text" class="form-control" placeholder="Search" name="user_query" required>
                           
                           <span class="input-group-btn">
                           
                           <button type="submit" name="search" value="Search" class="btn btn-primary">
                               
                               <i class="fa fa-search"></i>
                               
                           </button>
                           
                           </span>
                           
                       </div>
                       
                   </form>
                   
               </div>
               
           </div>
           
       </div>
       
   </div>