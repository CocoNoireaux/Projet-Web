<?php 

$con = mysqli_connect("localhost","root","","ecom_store");

?>

<!--Connexion avec la base de donnée ecom_store-->
