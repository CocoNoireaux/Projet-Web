<!-- verification.php -->

<?php 

    $active='Account'; // si on clique sur compte //
    include("includes/header.php");

?>
   
   <div id="content">
       <div class="container">
           <div class="col-md-12">
               
               <ul class="breadcrumb">
                   <li>
                       <a href="index.php">Acceuil</a>
                   </li>
                   <li>
                       Registre
                   </li>
               </ul>
               
           </div>
           
           <div class="col-md-3">
   
   <?php 
    
    include("includes/sidebar.php");
    
    ?>
               
           </div>
           
           <div class="col-md-9">
           
           <?php  // verification connexion avec email acheteur // 
           
           if(!isset($_SESSION['customer_email'])){
               
               include("customer/customer_login.php");
               
           }else{
               
               include("payment_options.php");
               
           }
           
           ?>
           
           </div>
           
       </div>
   </div>
   
   <?php 
    
    include("includes/footer.php");
    
    ?>
    
    <script src="js/jquery-331.min.js"></script> <!-- Bibliothèque jquery -->
    <script src="js/bootstrap-337.min.js"></script> <!-- Bibliothèque bootstrap -->
    
    
</body>
</html>