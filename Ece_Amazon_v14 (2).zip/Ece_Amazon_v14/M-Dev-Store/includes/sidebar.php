<!-- Affichage côté de la page web -->

<div class="panel panel-default sidebar-menu">
    <div class="panel-heading"><!-- Début panel -->
        <h3 class="panel-title">Categories produits</h3>
    </div><!-- Fin panel -->
    
    <div class="panel-body"><!-- Début panel-body  -->
        <ul class="nav nav-pills nav-stacked category-menu">
            
            <?php getPCats(); ?> <!-- Récupération catégories_produit -->
            
        </ul>
    </div><!-- Fin panel-body  -->
    
</div>


<div class="panel panel-default sidebar-menu">
    <div class="panel-heading"><!-- Début panel -->
        <h3 class="panel-title">Categories</h3>
    </div><!-- Fin panel -->
    
    <div class="panel-body"><!-- Début panel-body  -->
        <ul class="nav nav-pills nav-stacked category-menu">
            
            <?php getCats(); ?> <!-- Récupération catégories -->
            
        </ul>
    </div><!-- Fin panel-body  -->
    
</div>