<!-- Utilisation de Bootstrap -->
<!-- Affichage bas de page -->

<div id="footer"><!-- Début du footer -->
    <div class="container"><!-- Début de container -->
        <div class="row"><!-- row Begin -->
            <div class="col-sm-6 col-md-3"><!-- Début col-sm-6 col-md-3 -->
               
               <h4>Pages</h4>
                
                <ul><!-- Début ul -->
                    <li><a href="cart.php">Mon panier</a></li>
                    <li><a href="vente_flash.php">Vente Flash</a></li>
                    <li><a href="shop.php">Boutique</a></li>
                    <li><a href="customer/my_account.php">Mon compte</a></li>
                </ul><!-- Fin ul -->
                
                <hr>
                
                <h4>Espace utilisateur</h4>
                
                <ul><!-- Début ul -->
                           
                           <!-- Début de php -->
                           <?php 
                           
                           if(!isset($_SESSION['customer_email'])){
                               
                               echo"<a href='checkout.php'>Se connecter</a>"; // Référence, accès à la page
                               
                           }else{
                               
                              echo"<a href='customer/my_account.php?my_orders'>Mon compte</a>"; 
                               
                           }
                           
                           ?>
                    
                    <li><a href="customer_register.php">S'inscrire</a></li> <!--Référence, accès à la page -->
                </ul><!-- Fin ul-->
                
                <hr class="hidden-md hidden-lg hidden-sm">
                
            </div><!-- Fin col-sm-6 col-md-3 -->
            
            <div class="com-sm-6 col-md-3"><!-- Début col-sm-6 col-md-3 -->
                
                <h4>Catégories des produits</h4>
                
                <ul><!-- Début ul -->
                
                    <?php 
                    
                        $get_p_cats = "select * from product_categories"; // Accès table catégories_produit
                    
                        $run_p_cats = mysqli_query($con,$get_p_cats);
                    
                        while($row_p_cats=mysqli_fetch_array($run_p_cats)){
                            
                            $p_cat_id = $row_p_cats['p_cat_id'];
                            
                            $p_cat_title = $row_p_cats['p_cat_title'];
                            
                            echo "
                            
                                <li>
                                
                                    <a href='shop.php?p_cat=$p_cat_id'>
                                    
                                        $p_cat_title
                                    
                                    </a>
                                
                                </li>
                            
                            ";
                            
                        }
                    
                    ?>
                
                </ul><!-- Fin ul -->
                
                <hr class="hidden-md hidden-lg">
                
            </div><!-- Fin col-sm-6 col-md-3 -->
            
            <div class="col-sm-6 col-md-3"><!-- Début col-sm-6 col-md-3 -->
                
                <h4>Nos contacts</h4>
                
                <p>
                    
                    <strong>Groupe ECE Paris.Lyon</strong>
                    <br/>Immeuble POLLUX
                    <br/>37, Quai de Grenelle
                    <br/>Tel : 01 44 39 06 00
                    <br/>contact@ece.fr
                    <br/><strong>ECE Campus de Paris</strong>
                    
                </p>
                
                <a href="contact.php">Contactez nous ici</a> -->
                
                <hr class="hidden-md hidden-lg">
                
            </div><!-- Fin col-sm-6 col-md-3 -->
            
            <div class="col-sm-6 col-md-3">
                
                <h4>Abonnez vous !</h4>
                
                <p class="text-muted">
                    Ne rattez pas nos prochains produits.
                </p>
                
                <form action="https://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('https://feedburner.google.com/fb/a/mailverify?uri=ECE_Amazon', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true" method="post">
                    <div class="input-group">
                        
                        <input type="text" class="form-control" name="email">
                        
                        <input type="hidden" value="ECE_Amazon" name="uri"/><input type="hidden" name="loc" value="en_US"/>
                        
                        <span class="input-group-btn">
                            
                            <input type="submit" value="s'abonner" class="btn btn-default">
                            
                        </span>
                        
                    </div>
                </form>
                
                <hr>
                
                <h4>Partagez sur les réseaux</h4>
                
                <p class="social">
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-instagram"></a>
                    <a href="#" class="fa fa-google-plus"></a>
                    <a href="#" class="fa fa-envelope"></a>
                </p>
                
            </div>
        </div>
    </div><!-- Fin container -->
</div><!-- Fin footer -->


<div id="copyright">
    <div class="container">
        <div class="col-md-6">
            
            <p class="pull-left">&copy; 2019 ECE Paris.Lyon All Rights Reserve</p>
            
        </div>

    </div>
</div>