<!-- contact.php -->

<?php 
    
    $active='Contact'; // si on clique sur contact //
    include("includes/header.php");

?>
  
   <div id="content">
       <div class="container">
           <div class="col-md-12">
               
               <ul class="breadcrumb">
                   <li>
                       <a href="index.php">Accueil</a>
                   </li>
                   <li>
                       Contactez nous
                   </li>
               </ul>
               
           </div>
           
           <div class="col-md-3">
   
   <?php 
    
    include("includes/sidebar.php");
    
    ?>
               
           </div>
           
           <div class="col-md-9">
               
               <div class="box">
                   
                   <div class="box-header">
                       
                       <center>
                           
                           <h2> Contactez nous</h2>
                           
                           <p class="text-muted">
                               
                               Si vous avez des questions, n'hésitez pas à nous contacter. Notre service client fonctionne <strong>24/7</strong>
                               
                           </p>
                           
                       </center>
                       
                       <form action="contact.php" method="post">
                           
                           <div class="form-group">
                               
                               <label>Nom</label>
                               
                               <input type="text" class="form-control" name="name" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Email</label>
                               
                               <input type="text" class="form-control" name="email" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Sujet</label>
                               
                               <input type="text" class="form-control" name="subject" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Message</label>
                               
                               <textarea name="message" class="form-control"></textarea>
                               
                           </div>
                           
                           <div class="text-center">
                               
                               <button type="submit" name="submit" class="btn btn-primary">
                               
                               <i class="fa fa-user-md"></i> Envoyer Message
                               
                               </button>
                               
                           </div>
                           
                       </form>
                       
                       <?php 
                       
                       if(isset($_POST['submit'])){
                           
                           /// Message à l'administrateur ///
                           
                           $sender_name = $_POST['name'];
                           
                           $sender_email = $_POST['email'];
                           
                           $sender_subject = $_POST['subject'];
                           
                           $sender_message = $_POST['message'];
                           
                           $receiver_email = "alexandre.avakian@edu.ece.fr";
                           
                           mail($receiver_email,$sender_name,$sender_subject,$sender_message,$sender_email);
                           
                           /// Message automatique ///
                           
                           $email = $_POST['email'];
                           
                           $subject = "Bienvenue sur mon site";
                           
                           $msg = "Merci pour votre message";
                           
                           $from = "alexandre.avakian@edu.ece.fr";
                           
                           mail($email,$subject,$msg,$from);
                           
                           echo "<h2 align='center'> Your message has sent sucessfully </h2>";
                           
                       }
                       
                       ?>
                       
                   </div>
                   
               </div>
               
           </div>
           
       </div>
   </div>
   
   <?php 
    
    include("includes/footer.php");
    
    ?>
    
    <script src="js/jquery-331.min.js"></script> <!-- Bibliothèque jquery-->
    <script src="js/bootstrap-337.min.js"></script> <!-- Bibliothèque bootstrap-->
</body>
</html>