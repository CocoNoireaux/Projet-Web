<!-- vendeur_register.php -->

<?php 

    $active='Account'; // si on clique sur compte dans le header//
    include("includes/header.php");

?>
   
   <div id="content">
       <div class="container">
           <div class="col-md-12">
               
               <ul class="breadcrumb">
                   <li>
                       <a href="index.php">Accueil</a>
                   </li>
                   <li>
                       s'inscrire vendeur
                   </li>
               </ul>
               
           </div>
           
           <div class="col-md-3">
   
   <?php 
    
    include("includes/sidebar.php"); // affichage menu sidebar //
    
    ?>
               
           </div>
           
           <div class="col-md-9">
               
               <div class="box">
                   
                   <div class="box-header">
                       
                       <center>
                           
                           <h2> Creation d'un nouveau compte vendeur </h2>
                           
                       </center>
                       
                       <form action="customer_register.php" method="post" enctype="multipart/form-data">
                           
                           <div class="form-group">
                               
                               <label>Prenom  Nom</label>
                               
                               <input type="text" class="form-control" name="c_name" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Email</label>
                               
                               <input type="text" class="form-control" name="c_email" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Mot de Passe</label>
                               
                               <input type="password" class="form-control" name="c_pass" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Pays</label>
                               
                               <input type="text" class="form-control" name="c_country" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Ville</label>
                               
                               <input type="text" class="form-control" name="c_city" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Telephone</label>
                               
                               <input type="text" class="form-control" name="c_contact" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Adresse</label>
                               
                               <input type="text" class="form-control" name="c_address" required>
                               
                           </div>
                           
                           <div class="form-group">
                               
                               <label>Photo de profil</label>
                               
                               <input type="file" class="form-control form-height-custom" name="c_image" required>
                               
                           </div>
                           
                           <div class="text-center">
                               
                               <button type="submit" name="register" class="btn btn-primary">
                               
                               <i class="fa fa-user-md"></i> Inscription
                               
                               </button>
                               
                           </div>
                           
                       </form>
                       
                   </div>
                   
               </div>
               
           </div>
           
       </div>
   </div>
   
   <?php 
    
    include("includes/footer.php");
    
    ?>
    
    <script src="js/jquery-331.min.js"></script> <!-- bibliothèque jquery -->
    <script src="js/bootstrap-337.min.js"></script> <!-- bibliothèque bootstrap -->
    
    
</body>
</html>

<!-- enregistrement profil -->
<?php 

if(isset($_POST['register'])){
    
    $c_name = $_POST['c_name'];
    
    $c_email = $_POST['c_email'];
    
    $c_pass = $_POST['c_pass'];
    
    $c_country = $_POST['c_country'];
    
    $c_city = $_POST['c_city'];
    
    $c_contact = $_POST['c_contact'];
    
    $c_address = $_POST['c_address'];
    
    $c_image = $_FILES['c_image']['name'];
    
    $c_image_tmp = $_FILES['c_image']['tmp_name'];
    
    $c_ip = getRealIpUser();
    
    move_uploaded_file($c_image_tmp,"vendre/vendeurs_images/$c_image");
    
    // insertion des données dans la table vendeur //
    $insert_vendeur = "insert into vendeur (vendeur_name,vendeur_email,vendeur_pass,vendeur_country,vendeur_city,vendeur_contact,vendeur_address,vendeur_image,vendeur_ip) values ('$c_name','$c_email','$c_pass','$c_country','$c_city','$c_contact','$c_address','$c_image','$c_ip')";
    
    $run_vendeur = mysqli_query($con,$insert_vendeur);
    
    $sel_cart = "select * from cart where ip_add='$c_ip'"; // accès à la table panier //
    
    $run_cart = mysqli_query($con,$sel_cart);
    
    $check_cart = mysqli_num_rows($run_cart);
    
    if($check_cart>0){
        
        
        
        $_SESSION['vendeur_email']=$c_email;
        
        echo "<script>alert('Vous avez été enregistré avec succès')</script>";
        
        echo "<script>window.open('checkout.php','_self')</script>";
        
    }else{
        
        
        
        $_SESSION['vendeur_email']=$c_email;
        
        echo "<script>alert('Vous avez été enregistré avec succès')</script>";
        
        echo "<script>window.open('index.php','_self')</script>";
        
    }
    
}

?>